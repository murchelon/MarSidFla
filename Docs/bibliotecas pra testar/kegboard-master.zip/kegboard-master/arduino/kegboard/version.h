#pragma once

// Version of the kegboard firmware. This is bumped whenever there's a
// significant new feature in the firmware.

#define FIRMWARE_VERSION 18
