# Kegbot Docs

This project contains documentation that doesn't fit in any other standalone
Kegbot project.

Most people should just browse the docs online: http://kegbot.org/docs/

## Building docs

```
$ sudo pip install sphinx
$ cd kegboard-build    # or any other doc dir
$ make html
```