.. _developer:

===============
Developer Notes
===============

This document contains various notes for developers.

.. toctree::
  :maxdepth: 2

  patch
  code-style
  docs
