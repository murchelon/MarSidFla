==========
Schematics
==========

Kegboard
========

.. image:: _static/images/kegboard-layout.png
.. image:: _static/images/kegboard-schematic.png

Coaster
=======

.. image:: _static/images/coaster-layout.png
.. image:: _static/images/coaster-schematic.png
