# Documentation Instructions

To build documentation:

    $ pip install sphinx
    $ make html
    $ open build/html/index.html

All docs are also available online at http://kegbot.org/docs
